
#include <stdio.h>

extern void enable_caches(void);

int main(void) {
	enable_caches();
	//printf("ARM Cortax-A7 program.\n");

	sm2_test();
	return 0;
}
